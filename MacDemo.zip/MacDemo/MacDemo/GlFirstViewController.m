//
//  GlFirstViewController.m
//  MacDemo
//
//  Created by gleeeli on 2020/3/18.
//  Copyright © 2020 gleeeli. All rights reserved.
//

#import "GlFirstViewController.h"
#import "ScaryData.h"

@interface GlFirstViewController ()<NSTabViewDelegate,NSTableViewDataSource>
@property (weak) IBOutlet NSTableView *tableView;
@property(nonatomic,strong) NSMutableArray *datas;
@end

@implementation GlFirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    self.tableView.delegate = (id)self;
//    self.tableView.dataSource = (id)self;
    
    self.datas = [[NSMutableArray alloc] init];
    
    static NSString *indentifier = @"TableCell";
    NSArray *array = @[@"123",@"456",@"789",@"100"];
    for (NSString *txt in array) {
        ScaryData *data = [[ScaryData alloc] init];
        data.identifier = indentifier;
        data.content = txt;
        [self.datas addObject:data];
    }
    
    [self.tableView reloadData];
}

- (void)tabView:(NSTabView *)tabView didSelectTabViewItem:(nullable NSTabViewItem *)tabViewItem {
    
}

- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView {
    return [self.datas count];
}


//- (nullable id)tableView:(NSTableView *)tableView objectValueForTableColumn:(nullable NSTableColumn *)tableColumn row:(NSInteger)row {
//    ScaryData *data = self.datas[row];
//    NSTableCellView *cell = [tableView makeViewWithIdentifier:data.identifier owner:self];
//    cell.textField.placeholderString = data.content;
//    NSLog(@"cell:%@",data.content);
//    return cell;
//}

- (nullable NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(nullable NSTableColumn *)tableColumn row:(NSInteger)row API_AVAILABLE(macos(10.7)) {
    ScaryData *data = self.datas[row];
    NSTableCellView *cell = [tableView makeViewWithIdentifier:data.identifier owner:self];
    cell.textField.placeholderString = data.content;
    NSLog(@"cell:%@",data.content);
    cell.textField.stringValue = data.content;
    return cell;
}
@end
