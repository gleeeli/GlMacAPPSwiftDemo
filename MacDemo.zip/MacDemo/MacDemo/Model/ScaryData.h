//
//  ScaryData.h
//  MacDemo
//
//  Created by gleeeli on 2020/3/18.
//  Copyright © 2020 gleeeli. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ScaryData : NSObject
@property(nonatomic, copy) NSString *identifier;
@property(nonatomic, copy) NSString *content;

@end

NS_ASSUME_NONNULL_END
