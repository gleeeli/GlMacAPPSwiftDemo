//
//  ScaryData.m
//  MacDemo
//
//  Created by gleeeli on 2020/3/18.
//  Copyright © 2020 gleeeli. All rights reserved.
//

#import "ScaryData.h"

@implementation ScaryData

@end
