//
//  AppDelegate.h
//  MacDemo
//
//  Created by gleeeli on 2020/3/18.
//  Copyright © 2020 gleeeli. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

