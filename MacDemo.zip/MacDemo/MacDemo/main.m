//
//  main.m
//  MacDemo
//
//  Created by gleeeli on 2020/3/18.
//  Copyright © 2020 gleeeli. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // Setup code that might create autoreleased objects goes here.
    }
    return NSApplicationMain(argc, argv);
}
